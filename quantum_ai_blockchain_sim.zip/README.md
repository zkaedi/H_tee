# Quantum AI Blockchain Simulator

This project simulates a futuristic hybrid of quantum computing, AI forecasting, RL healing, and blockchain logging.

## Structure
- `api/`: Flask endpoints
- `quantum/`: Quantum simulation logic
- `blockchain/`: Hash-linked block storage
- `rl/`: Reinforcement Learning for healing
- `models/`: ML forecasting models
- `utils/`: Helpers/utilities
- `plots/`: Output visualization

## How to Run
```bash
pip install -r requirements.txt
python main.py
```
